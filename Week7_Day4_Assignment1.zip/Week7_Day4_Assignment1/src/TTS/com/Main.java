package TTS.com;
public static void main(String[] args);

    public class Main {
    private String petName;
    private double petAge;
    private String petLocation;
    private String petType;

        //Empty Constructor
            public Main () { };

        // Create all attributes constructor below
         public Main(String name, double age, String location, String type) {
            petName = name;
            petAge = age;
            petLocation = location;
            petType = type;
             }

    //Getters below
    public String getPetName() {
        return petName;
    }
    public String getPetType() {
        return petType;
    }

    public double getPetAge() {
        return petAge;
    }
//Getters above


    //Setters below
    public void setPetName(String newPetName) {
        this.petName = newPetName;
    }

    public void setPetLocation(String newPetLocation) {
        this.petLocation = newPetLocation;
    }

    public void setPetAge(double newPetAge) { this.petAge = newPetAge; }
//Setters above
}

 // Experimenting below
 /*   public static void main(String[] args) {
         Main petObj = new Main();
         petObj.petName("Carly Sue Fukklehead");

	Main petObj = new Main("Carly Sue Fukklehead" , 2.5 , "Back Yard" , "Dog");  //Create an object of the class Main
    System.out.println(petObj.petName + "  " + petObj.petAge + "  " + petObj.petLocation + "  " + petObj.petType);
*/

