package TTS.com;

public class IceCream {
    private String iceCreamFlavor;
    private double numberOfIceCreamScoops;
    private boolean wantsIceCreamSprinkles;
    private String iceCreamTopping;

    //Empty Constructor
    public IceCream () { };

    // Create all attributes constructor below
    public IceCream(String flavor, double scoops, boolean sprinkles, String topping) {
        iceCreamFlavor = flavor;
        numberOfIceCreamScoops = scoops;
        wantsIceCreamSprinkles = sprinkles;
        iceCreamTopping = topping;
    }

    boolean wantsIceCreamSprinkles = wantsIceCreamSprinkles != albumLengthB;
    //*****Getters below*****
    public String getIceCreamFlavor() {
        return iceCreamFlavor;
    }

    public String getIceCreamTopping() {
        return iceCreamTopping;
    }

    public double getNumberOfIceCreamScoops() {
        return numberOfIceCreamScoops;
    }

    public boolean iceCreamSprinkles() {
        return iceCreamSprinkles;

    }
    //test boolean here
    public boolean wantsIceCreamSprinkles(){
       /* if wantsIceCreamSprinkles.equals(pwdRetypePwd.getText() {
            txtaError.setEditable(true);
            txtaError.setText("*Password didn't match!");
            txtaError.setForeground(Color.red);
            txtaError.setEditable(false);
            return false;
        }
        else {
            return true;
        }
*/
        //*****Getters above*****


    //*****Setters below*****
    public void setIceCreamFlavor(String newIceCreamFlavor) {
        this.iceCreamFlavor = newIceCreamFlavor;
    }

    public void setIceCreamSprinkles(String newIceCreamSprinkles) {
        this.iceCreamSprinkles = newIceCreamSprinkles;
    }

    public void setNumberOfIceCreamScoops(double newiceCreamScoops) {
        this.numberOfIceCreamScoops = newiceCreamScoops;
    }
//*****Setters above*****


    // Experimenting below
  /*  public static void main(String[] args) {
        Main petObj = new Main();
        petObj.petName("Carly Sue Fukklehead");

        Main petObj = new Main("Carly Sue Fukklehead" , 2.5 , "Back Yard" , "Dog");  //Create an object of the class Main
        System.out.println(petObj.petName + "  " + petObj.petAge + "  " + petObj.petLocation + "  " + petObj.petType);

*/
    }

